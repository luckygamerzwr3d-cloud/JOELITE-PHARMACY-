from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from models import db, Product, Batch, Sale, SaleItem

pos_bp = Blueprint('pos', __name__)

@pos_bp.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')

@pos_bp.route('/pos')
@login_required
def pos_terminal():
    products = Product.query.all()
    return render_template('pos.html', products=products)

@pos_bp.route('/checkout', methods=['POST'])
@login_required
def checkout():
    data = request.json
    cart_items = data.get('items', [])
    
    if not cart_items:
        return jsonify({'error': 'Cart is empty'}), 400

    total_amount = 0
    sale = Sale(cashier_id=current_user.id, total_amount=0)
    db.session.add(sale)

    for item in cart_items:
        # FEFO Logic: Fetch earliest expiring batch with available quantity
        batch = Batch.query.filter(Batch.product_id == item['product_id'], Batch.quantity >= item['qty'])\
                           .order_by(Batch.expiry_date.asc()).first()
        
        if not batch:
            db.session.rollback()
            return jsonify({'error': f'Insufficient stock for product ID {item["product_id"]}'}), 400

        batch.quantity -= item['qty']
        subtotal = item['qty'] * batch.selling_price
        total_amount += subtotal

        sale_item = SaleItem(
            sale=sale,
            batch_id=batch.id,
            quantity=item['qty'],
            unit_price=batch.selling_price
        )
        db.session.add(sale_item)

    sale.total_amount = total_amount
    db.session.commit()

    return jsonify({'success': True, 'sale_id': sale.id, 'total': total_amount})