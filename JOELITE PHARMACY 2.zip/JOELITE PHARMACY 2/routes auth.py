from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from models import db, Product, Batch
from datetime import datetime

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/products')
@login_required
def list_products():
    products = Product.query.all()
    return render_template('products.html', products=products)

@inventory_bp.route('/batch/add', methods=['POST'])
@login_required
def add_batch():
    product_id = request.form.get('product_id')
    batch_num = request.form.get('batch_number')
    quantity = int(request.form.get('quantity', 0))
    cost_price = float(request.form.get('cost_price', 0.0))
    selling_price = float(request.form.get('selling_price', 0.0))
    expiry_date = datetime.strptime(request.form.get('expiry_date'), '%Y-%m-%d').date()

    new_batch = Batch(
        product_id=product_id,
        batch_number=batch_num,
        quantity=quantity,
        cost_price=cost_price,
        selling_price=selling_price,
        expiry_date=expiry_date
    )
    db.session.add(new_batch)
    db.session.commit()
    flash('Batch added successfully', 'success')
    return redirect(url_for('inventory.list_products'))