
# JOELITE PHARMACY V7 — Prototype

This is a functional Flask + SQLite pharmacy-management prototype.

## New in V7
- Product entry now includes:
  - Brand name
  - Generic name
  - Short form name / abbreviation
  - Strength
  - Dosage form
  - Category
  - Price per sachet
  - Price per pack
  - Units per pack
  - Low-stock threshold
  - Product photo
  - Batch/expiry/supplier information
- Final-touch modules included:
  - Dashboard alerts
  - POS with automatic stock deduction
  - FEFO-style batch allocation
  - Expiry monitoring
  - Sales history
  - Reports
  - Referrals
  - Staff list
  - Database backup
  - Floating Pharm Lucky assistant
  - First-time onboarding
  - Audit-log foundation
  - Responsive/mobile layout

## Run
Python 3.10+ recommended.

pip install -r requirements.txt
python app.py

Then open http://127.0.0.1:5000

Demo:
Email: admin@joelite.local
Password: ChangeMe123!

## Important
The Gmail signup flow in this prototype is a development flow, not true Google OAuth. Before production deployment, replace it with Google OpenID/OAuth authentication and harden sessions, secrets, backups, permissions, and database hosting.

Pharm Lucky is deliberately pharmacist-reviewed decision support. It does not independently authorize prescriptions or individualized dosing.

Before production use, have the pharmacist/owner review workflows, privacy, controlled-drug handling, prescription-only workflows, and applicable Nigerian pharmacy requirements.
